create definer = root@localhost view report_view as
select ifnull(`health`.`tbl_report`.`report_id`, '')                                      AS `report_id`,
       ifnull(`health`.`tbl_report`.`type_id`, '')                                        AS `type_id`,
       ifnull(`health`.`tbl_report`.`patient_firstname`, '')                              AS `patient_firstname`,
       ifnull(`health`.`tbl_report`.`patient_lastname`, '')                               AS `patient_lastname`,
       ifnull(`health`.`tbl_report`.`patient_phone`, '')                                  AS `patient_phone`,
       ifnull(`health`.`tbl_report`.`patient_email`, '')                                  AS `patient_email`,
       ifnull(`health`.`tbl_report`.`patient_birth`, '')                                  AS `patient_birth`,
       ifnull(`health`.`tbl_report`.`patient_passport`, '')                               AS `patient_passport`,
       ifnull(`health`.`tbl_report`.`sample_taken`, '')                                   AS `sample_taken`,
       ifnull(`health`.`tbl_report`.`handled_at`, '')                                     AS `handled_at`,
       ifnull(`health`.`tbl_report`.`pdf_file_url`, '')                                   AS `pdf_file_url`,
       ifnull(`health`.`tbl_report`.`pdf_file_name`, '')                                  AS `pdf_file_name`,
       ifnull(`health`.`tbl_report`.`report_created_at`, '')                              AS `report_created_at`,
       ifnull(`health`.`tbl_report`.`report_updated_at`, '')                              AS `report_updated_at`,
       case
           when `health`.`tbl_report`.`type_id` = 1 then 'Visby PCR'
           when `health`.`tbl_report`.`type_id` = 2 then 'Antigen'
           when `health`.`tbl_report`.`type_id` = 3 then 'Accula'
           when `health`.`tbl_report`.`type_id` = 4 then 'Antibody'
           else '' end                                                                    AS `type`,
       ifnull(if(`health`.`tbl_report`.`patient_gender` = 0, 'Male', 'Female'), '')       AS `patient_gender`,
       ifnull(if(`health`.`tbl_report`.`report_results` = 0, 'Negative', 'Positive'), '') AS `report_results`,
       ifnull(`health`.`tbl_type`.`name`, '')                                             AS `name`
from (`health`.`tbl_report`
         join `health`.`tbl_type` on (`health`.`tbl_report`.`type_id` = `health`.`tbl_type`.`id`));

